<?php 

// use PHPUnit\Extensions\Selenium2TestCase;
use Facebook\WebDriver\Remote\DesiredCapabilities;
use Facebook\WebDriver\Remote\RemoteWebDriver;
use Facebook\WebDriver\WebDriverBy;
use Facebook\WebDriver\WebDriverExpectedCondition;
use Facebook\WebDriver\WebDriverKeys;
use PHPUnit\Framework\TestCase;

// class UserSubscriptionTest extends PHPUnit_Extensions_Selenium2TestCase
class UserSubscriptionTest extends TestCase
{
    public function setUp()
    {
        // $this->setHost('localhost');
        // $this->setPort(4444);
        // $this->setBrowserUrl('https://google.com');
        // $this->setBrowser('firefox');

        $desired_capabilities = DesiredCapabilities::chrome()->setPlatform('LINUX')->setVersion('latest');
        $this->_session = RemoteWebDriver::create("http://localhost:4444/wd/hub",
            $desired_capabilities, 120000
        );
    }

    public function testIfItLoads(){
        $url = 'https://www.google.com/';
        $this->_session->get($url);
        $driver = $this->_session;

        $location = function() use ($driver){
            return $driver->executeScript("return window.location.href");

        };
        // var_dump($test);
        $this->assertEquals($location(), $url);

        $this->assertEquals('Google', $this->_session->getTitle());

         $driver->wait()->until(
            WebDriverExpectedCondition::presenceOfElementLocated(WebDriverBy::id("lst-ib"))
        );

        $el = $driver->findElement(WebDriverBy::id("lst-ib"));
        $el->sendKeys("Natalia Afanasiuc");
        $driver->wait(500);
        $el->sendKeys(WebDriverKeys::ENTER);

        // $driver->sleep(200000000);
         $driver->wait()->until(
            WebDriverExpectedCondition::presenceOfElementLocated(WebDriverBy::cssSelector("div#hdtb-msb-vis > div:first-child + div > a"))
        );

         $driver->findElement(WebDriverBy::cssSelector("div#hdtb-msb-vis > div:first-child + div > a"))->click();

        $driver->wait(10, 500)->until(WebDriverExpectedCondition::titleIs('My Page'));


        $this->$this->assertNotEquals($location(), $url);

    }

    public function tearDown() 
    {
        // $this->stop();
        // $this->sendTestStatusToTestingBot();

        $this->_session->quit();

        unset($this->_session);
        parent::tearDown();
    }
}